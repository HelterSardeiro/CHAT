<?php
$nick = $_POST['nick'];
$cor = $_POST['cor'];
if($nick == ""){
echo "<script> location.href='index.htm'; </script>";
exit;
}
?>
<html>
<head>
  <title>Bate Papo</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
  <style type="text/css">
  	.jumbotron{
  		background-color: #5F9EA0;
  	}
  </style>
</head>
<body><font face="Verdana" size="2" color="#FFFFFF">

 <div class="jumbotron">
 	<iframe name="chat" src="chat.php" width="100%" height="80%" frameborder="0">Atualize seu navegador.</iframe>
 	<br>
 </div>
 <div >
 	<iframe name="ultimo" src="ultima.php" frameborder="0" width=300 height=16 marginwidth=0 marginheight=0 hspace=0 vspace=0 frameborder=0 scrolling=no>Favor atualizar seu navegador.</iframe>
 </div>
<!--FORM DE FALA-->
<hr color="white">
<form class="form-control" action="gravar.php" method="post" target="chat">
 <font color="<?php echo $cor ?>"><b><?php echo $nick ?></b></font color="<?php echo $cor ?>">
<input class="form-control" name="nick" type="hidden" value="<?php echo $nick ?>">
<input class="form-control" name="cor" type="hidden" value="<?php echo $cor ?>">
<select class="form-control" name="acao">
<option value="fala" selected>fala</option>
<option value="grita">grita</option>
<option value="beija">beija</option>
<option value="canta">canta</option>
<option value="pergunta">pergunta</option>
<option value="concorda">concorda</option>
<option value="discorda">discorda</option>
<option value="desculpa-se">desculpa-se</option>
<option value="surpreende-se">surpreende-se</option>
<option value="sorri">sorri</option>
<option value="diverte-se">diverte-se</option>
<option value="briga">briga</option>
<option value="d� o fora">d� o fora</option>
  </select> : 
  <input class="form-control" type="text" name="texto">
   <input class="btn-sucess" type="submit" value="Falar">
</form>
<form class="form-control" action="sair.php" method="post">
<input class="form-control" name="nick" type="hidden" value="<?php echo $nick ?>">
<input class="form-control" name="cor" type="hidden" value="<?php echo $cor ?>">
<input class="btn-secondary" type="submit" value="Sair">
</form>
</font>
</body>
</html>