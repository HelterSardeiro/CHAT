<html>
<head>
<META HTTP-EQUIV="Refresh" CONTENT="5;URL=ultima.php">
</head>
<body bgcolor="#0aacba"><font face="Verdana" size="2" color="white">
<b>�ltima mensagem enviada �s <?php include("ultima.txt"); ?>.</b></font>
</body>
</html>