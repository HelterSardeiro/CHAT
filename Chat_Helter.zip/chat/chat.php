<html>
<head>
<title>Bate Papo</title>
<META HTTP-EQUIV="Refresh" CONTENT="5;URL=chat.php">
<meta charset="utf-8">
<script language="javascript">
function ultima() {
location.href = "#ultima";
}
</script>
<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css">
<style type="text/css">
	.jumbotron{
		background-color: #005baf;
	}
</style>
</head>
<body onLoad="javascript:ultima()">
<div class="jumbotron">
<?php include("chat.txt"); ?>
<a name="ultima"> </a>
</div>
</body>
</html>